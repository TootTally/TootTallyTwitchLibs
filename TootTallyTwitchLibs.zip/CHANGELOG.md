#### Changelog:
`v0.1.0` -> `v1.0.0`

```diff
+ TootTally Twitch Libs API Implementation
```

