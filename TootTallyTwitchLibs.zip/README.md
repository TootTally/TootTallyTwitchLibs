# TootTally Module Template
This repository is intended to be used as a template for future modules for the [TootTally](https://toottally.com) project.
